from __future__ import annotations

from dataclasses import asdict

from .auto_fix_loop import AutoFixLoopService
from .dispatcher import CommandDispatcher
from .fix_planner import CompileFixPlanner
from .models import ToolResponse
from .patch_service import PatchApplyService
from .protocol import new_id
from .responses import fail, ok
from .server import WsOrchestratorServer


class McpToolFacade:
    def __init__(self, server: WsOrchestratorServer) -> None:
        self.server = server
        workspace_root = "."
        session = server.session_manager.active
        if session and session.project_path:
            workspace_root = session.project_path

        self.dispatcher = CommandDispatcher(transport=server, state=server.state)
        self.patch_service = PatchApplyService(workspace_root=workspace_root)
        self.fix_planner = CompileFixPlanner(workspace_root=workspace_root)
        self.auto_fix_loop = AutoFixLoopService(
            dispatcher=self.dispatcher,
            state=server.state,
            patch_service=self.patch_service,
            planner=self.fix_planner,
        )

    def _sync_workspace_root_from_session(self) -> None:
        session = self.server.session_manager.active
        if not session or not session.project_path:
            return
        self.patch_service.set_workspace_root(session.project_path)
        self.fix_planner.workspace_root = self.patch_service.workspace_root

    async def open_editor(self, command: str = "", wait_for_connect_ms: int = 60000) -> ToolResponse:
        request_id = new_id("req")
        if self.server.session_manager.is_connected():
            self._sync_workspace_root_from_session()
            session = self.server.session_manager.active
            return ok(request_id, {"started": False, "connected": True, "sessionId": session.session_id if session else ""})
        return fail(request_id, "UNITY_NOT_CONNECTED", "未检测到 Unity 连接", {"waitForConnectMs": wait_for_connect_ms, "command": command})

    async def compile(self) -> ToolResponse:
        request_id = new_id("req")
        return await self.dispatcher.call(request_id, "compile.request", {"requestId": request_id}, timeout_ms=120000)

    async def compile_status(self, compile_request_id: str = "") -> ToolResponse:
        request_id = new_id("req")
        compile_state = self.server.state.compile
        return ok(
            request_id,
            {
                "status": compile_state.status,
                "errorCount": compile_state.error_count,
                "warningCount": compile_state.warning_count,
                "startedAt": compile_state.started_at,
                "finishedAt": compile_state.finished_at,
                "compileRequestId": compile_request_id or compile_state.compile_request_id,
            },
        )

    async def compile_errors(self, compile_request_id: str = "") -> ToolResponse:
        request_id = new_id("req")
        errors = self.server.state.compile.errors
        return ok(request_id, {"errors": errors, "total": len(errors), "compileRequestId": compile_request_id})

    async def auto_fix_start(self, max_iterations: int = 20, stop_when_no_error: bool = True) -> ToolResponse:
        self._sync_workspace_root_from_session()
        request_id = new_id("req")
        loop = await self.auto_fix_loop.start(max_iterations=max_iterations, stop_when_no_error=stop_when_no_error)
        return ok(request_id, asdict(loop))

    async def auto_fix_stop(self, loop_id: str) -> ToolResponse:
        request_id = new_id("req")
        loop = self.auto_fix_loop.stop(loop_id)
        if not loop:
            return fail(request_id, "INVALID_PAYLOAD", "loopId 不存在", {"loopId": loop_id})
        return ok(request_id, asdict(loop))

    async def auto_fix_status(self) -> ToolResponse:
        request_id = new_id("req")
        loop = self.auto_fix_loop.status()
        if not loop:
            return ok(request_id, {"status": "idle"})
        return ok(request_id, asdict(loop))

    async def playmode_start(self) -> ToolResponse:
        request_id = new_id("req")
        return await self.dispatcher.call(request_id, "playmode.set", {"action": "play"})

    async def playmode_stop(self) -> ToolResponse:
        request_id = new_id("req")
        return await self.dispatcher.call(request_id, "playmode.set", {"action": "stop"})

    async def mouse_event(self, action: str, button: str, x: float, y: float, target_window: str, modifiers: list[str] | None = None) -> ToolResponse:
        request_id = new_id("req")
        payload = {
            "action": action,
            "button": button,
            "x": x,
            "y": y,
            "targetWindow": target_window,
            "modifiers": modifiers or [],
        }
        return await self.dispatcher.call(request_id, "mouse.event", payload)

    async def editor_state(self) -> ToolResponse:
        request_id = new_id("req")
        s = self.server.state.editor
        return ok(request_id, {"connected": s.connected, "isCompiling": s.is_compiling, "playModeState": s.play_mode_state, "activeScene": s.active_scene})
