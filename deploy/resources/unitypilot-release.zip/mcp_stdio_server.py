from __future__ import annotations

import asyncio
import json
import sys
from typing import Any

from .server import WsOrchestratorServer
from .tool_facade import McpToolFacade

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "unitypilot"
SERVER_VERSION = "0.1.0"


TOOLS: list[dict[str, Any]] = [
    {
        "name": "unity.open_editor",
        "description": "检查 Unity 连接并返回会话信息。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "waitForConnectMs": {"type": "integer", "minimum": 5000, "maximum": 180000},
            },
            "required": [],
        },
    },
    {"name": "unity.compile", "description": "触发 Unity 编译。", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {
        "name": "unity.compile_status",
        "description": "获取最近一次编译状态。",
        "inputSchema": {
            "type": "object",
            "properties": {"compileRequestId": {"type": "string"}},
            "required": [],
        },
    },
    {
        "name": "unity.compile_errors",
        "description": "获取最近一次结构化编译错误。",
        "inputSchema": {
            "type": "object",
            "properties": {"compileRequestId": {"type": "string"}},
            "required": [],
        },
    },
    {
        "name": "unity.auto_fix_start",
        "description": "启动自动修复循环。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "maxIterations": {"type": "integer", "minimum": 1, "maximum": 50},
                "stopWhenNoError": {"type": "boolean"},
            },
            "required": [],
        },
    },
    {
        "name": "unity.auto_fix_stop",
        "description": "停止自动修复循环。",
        "inputSchema": {
            "type": "object",
            "properties": {"loopId": {"type": "string"}},
            "required": ["loopId"],
        },
    },
    {"name": "unity.auto_fix_status", "description": "读取自动修复循环状态。", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "unity.playmode_start", "description": "进入 PlayMode。", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "unity.playmode_stop", "description": "退出 PlayMode。", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {
        "name": "unity.mouse_event",
        "description": "执行 Unity 编辑器鼠标动作。",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string"},
                "button": {"type": "string"},
                "x": {"type": "number"},
                "y": {"type": "number"},
                "targetWindow": {"type": "string"},
                "modifiers": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["action", "button", "x", "y", "targetWindow"],
        },
    },
    {"name": "unity.editor_state", "description": "获取 Unity 编辑器状态快照。", "inputSchema": {"type": "object", "properties": {}, "required": []}},
]


def _read_mcp_message_blocking() -> dict[str, Any] | None:
    headers: dict[str, str] = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        key, value = line.decode("utf-8").split(":", 1)
        headers[key.strip().lower()] = value.strip()

    content_length = int(headers.get("content-length", "0"))
    if content_length <= 0:
        return None

    body = sys.stdin.buffer.read(content_length)
    if not body:
        return None
    return json.loads(body.decode("utf-8"))


def _write_mcp_message_blocking(payload: dict[str, Any]) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
    sys.stdout.buffer.write(header)
    sys.stdout.buffer.write(body)
    sys.stdout.buffer.flush()


def _ok_response(req_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _error_response(req_id: Any, code: int, message: str) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


class UnityPilotMcpStdioServer:
    def __init__(self) -> None:
        self.orchestrator = WsOrchestratorServer(host="127.0.0.1", port=8765)
        self.facade = McpToolFacade(self.orchestrator)
        self._orchestrator_task: asyncio.Task | None = None

    async def run(self) -> None:
        self._orchestrator_task = asyncio.create_task(self.orchestrator.start())

        try:
            while True:
                msg = await asyncio.to_thread(_read_mcp_message_blocking)
                if msg is None:
                    break
                await self._handle_message(msg)
        finally:
            if self._orchestrator_task:
                self._orchestrator_task.cancel()

    async def _handle_message(self, msg: dict[str, Any]) -> None:
        method = msg.get("method")
        req_id = msg.get("id")

        if method == "initialize":
            res = _ok_response(
                req_id,
                {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
                },
            )
            await asyncio.to_thread(_write_mcp_message_blocking, res)
            return

        if method == "notifications/initialized":
            return

        if method == "tools/list":
            res = _ok_response(req_id, {"tools": TOOLS})
            await asyncio.to_thread(_write_mcp_message_blocking, res)
            return

        if method == "tools/call":
            params = msg.get("params") or {}
            tool_name = str(params.get("name", ""))
            args = params.get("arguments") or {}
            result = await self._call_tool(tool_name, args)
            res = _ok_response(req_id, result)
            await asyncio.to_thread(_write_mcp_message_blocking, res)
            return

        if req_id is not None:
            res = _error_response(req_id, -32601, f"Method not found: {method}")
            await asyncio.to_thread(_write_mcp_message_blocking, res)

    async def _call_tool(self, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        if tool_name == "unity.open_editor":
            r = await self.facade.open_editor(command=str(args.get("command", "")), wait_for_connect_ms=int(args.get("waitForConnectMs", 60000)))
        elif tool_name == "unity.compile":
            r = await self.facade.compile()
        elif tool_name == "unity.compile_status":
            r = await self.facade.compile_status(compile_request_id=str(args.get("compileRequestId", "")))
        elif tool_name == "unity.compile_errors":
            r = await self.facade.compile_errors(compile_request_id=str(args.get("compileRequestId", "")))
        elif tool_name == "unity.auto_fix_start":
            r = await self.facade.auto_fix_start(
                max_iterations=int(args.get("maxIterations", 20)),
                stop_when_no_error=bool(args.get("stopWhenNoError", True)),
            )
        elif tool_name == "unity.auto_fix_stop":
            r = await self.facade.auto_fix_stop(loop_id=str(args.get("loopId", "")))
        elif tool_name == "unity.auto_fix_status":
            r = await self.facade.auto_fix_status()
        elif tool_name == "unity.playmode_start":
            r = await self.facade.playmode_start()
        elif tool_name == "unity.playmode_stop":
            r = await self.facade.playmode_stop()
        elif tool_name == "unity.mouse_event":
            r = await self.facade.mouse_event(
                action=str(args.get("action", "")),
                button=str(args.get("button", "")),
                x=float(args.get("x", 0.0)),
                y=float(args.get("y", 0.0)),
                target_window=str(args.get("targetWindow", "scene")),
                modifiers=list(args.get("modifiers", [])),
            )
        elif tool_name == "unity.editor_state":
            r = await self.facade.editor_state()
        else:
            return {
                "content": [{"type": "text", "text": json.dumps({"ok": False, "error": {"code": "COMMAND_NOT_FOUND", "message": f"unknown tool: {tool_name}"}}, ensure_ascii=False)}],
                "isError": True,
            }

        payload = {
            "ok": r.ok,
            "data": r.data,
            "error": as_error_dict(r.error),
            "requestId": r.request_id,
            "timestamp": r.timestamp,
        }
        return {
            "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False)}],
            "isError": not r.ok,
        }


def as_error_dict(error: Any) -> dict[str, Any] | None:
    if error is None:
        return None
    return {"code": error.code, "message": error.message, "detail": error.detail}


async def main() -> None:
    server = UnityPilotMcpStdioServer()
    await server.run()


if __name__ == "__main__":
    asyncio.run(main())
