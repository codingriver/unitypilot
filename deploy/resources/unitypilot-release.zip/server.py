from __future__ import annotations

import asyncio
import json
from typing import Any

import websockets
from websockets.server import WebSocketServerProtocol

from .dispatcher import WsTransport
from .protocol import PROTOCOL_VERSION, from_wire, now_ms, to_wire
from .session_manager import SessionManager
from .state_store import StateStore


class WsOrchestratorServer(WsTransport):
    def __init__(self, host: str = "127.0.0.1", port: int = 8765, heartbeat_interval_ms: int = 2000) -> None:
        self.host = host
        self.port = port
        self.heartbeat_interval_ms = heartbeat_interval_ms
        self.session_manager = SessionManager(heartbeat_timeout_ms=heartbeat_interval_ms * 3)
        self.state = StateStore()
        self._ws: WebSocketServerProtocol | None = None
        self._pending: dict[str, asyncio.Future] = {}

    async def start(self) -> None:
        async with websockets.serve(self._handle, self.host, self.port):
            await asyncio.Future()

    def is_ready(self) -> bool:
        return self._ws is not None and self.session_manager.is_connected()

    def register_pending(self, command_id: str) -> asyncio.Future:
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        self._pending[command_id] = fut
        return fut

    async def send_command(self, command_id: str, name: str, payload: dict[str, Any]) -> None:
        if not self._ws or not self.session_manager.active:
            return
        msg = {
            "id": command_id,
            "type": "command",
            "name": name,
            "payload": payload,
            "timestamp": now_ms(),
            "sessionId": self.session_manager.active.session_id,
            "protocolVersion": PROTOCOL_VERSION,
        }
        await self._ws.send(json.dumps(msg, ensure_ascii=False))

    async def _handle(self, websocket: WebSocketServerProtocol) -> None:
        self._ws = websocket
        heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        try:
            async for raw in websocket:
                incoming = from_wire(json.loads(raw))
                await self._handle_message(incoming)
        finally:
            heartbeat_task.cancel()
            self._ws = None
            self.session_manager.disconnect()

    async def _handle_message(self, message) -> None:
        if message.type == "hello" and message.name == "session.hello":
            self.session_manager.on_hello(message.session_id, message.payload)
            ack = {
                "id": message.id,
                "type": "result",
                "name": "session.hello",
                "payload": {"accepted": True, "heartbeatIntervalMs": self.heartbeat_interval_ms},
                "timestamp": now_ms(),
                "sessionId": message.session_id,
                "protocolVersion": PROTOCOL_VERSION,
            }
            if self._ws:
                await self._ws.send(json.dumps(ack, ensure_ascii=False))
            return

        if message.type == "heartbeat":
            self.session_manager.on_heartbeat(message.session_id)
            return

        if message.type in ("result", "error"):
            fut = self._pending.pop(message.id, None)
            if fut and not fut.done():
                fut.set_result(to_wire(message))
            return

        if message.type == "event":
            if message.name == "compile.status":
                self.state.update_compile_status(message.payload)
            elif message.name == "compile.errors":
                self.state.update_compile_errors(message.payload)
            elif message.name == "editor.state":
                self.state.update_editor_state(message.payload)
            elif message.name == "playmode.changed":
                self.state.editor.play_mode_state = str(message.payload.get("state", self.state.editor.play_mode_state))

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(self.heartbeat_interval_ms / 1000)
            if not self._ws or not self.session_manager.active:
                continue
            hb = {
                "id": f"hb-{now_ms()}",
                "type": "heartbeat",
                "name": "session.heartbeat",
                "payload": {},
                "timestamp": now_ms(),
                "sessionId": self.session_manager.active.session_id,
                "protocolVersion": PROTOCOL_VERSION,
            }
            await self._ws.send(json.dumps(hb, ensure_ascii=False))
